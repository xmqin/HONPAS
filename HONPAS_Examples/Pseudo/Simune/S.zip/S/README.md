Ground State
S [1s2 2s2 2p6] 3s2 3p4 3d0 4f0
