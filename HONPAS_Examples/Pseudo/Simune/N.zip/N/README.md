Ground State
N [1s2] 2s2 2p3 3d0 4f0
