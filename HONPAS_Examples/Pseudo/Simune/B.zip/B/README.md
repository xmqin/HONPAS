Ground state
B [1s2] 2s2 2p1 3d0 4f0
