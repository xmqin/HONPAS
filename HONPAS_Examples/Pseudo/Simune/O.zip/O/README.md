Ground state
O [1s2] 2s2 2p4 3d0 4f0
