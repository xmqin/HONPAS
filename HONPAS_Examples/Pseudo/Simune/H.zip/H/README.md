Ground state
H 1s1 2p0 3d0 4f0
